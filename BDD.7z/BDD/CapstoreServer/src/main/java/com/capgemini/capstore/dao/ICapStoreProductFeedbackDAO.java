package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
@Repository
public interface ICapStoreProductFeedbackDAO extends JpaRepository<ProductFeedback, Integer> {


	public List<ProductFeedback> findByProduct(Product product);
	
	public List<ProductFeedback> findByCustomer(Customer customer);
	
	public ProductFeedback findById(int feedback_id);
}
